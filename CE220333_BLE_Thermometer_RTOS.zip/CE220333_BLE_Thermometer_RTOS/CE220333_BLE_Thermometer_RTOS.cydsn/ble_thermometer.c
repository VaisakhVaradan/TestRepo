/******************************************************************************
* File Name: ble_thermometer.c
*
* Version: 1.00
*
* Description: This file contains the task and functions that handle BLE HTS 
*              service
*
* Related Document: CE220333_BLE_Thermometer_RTOS.pdf
*
* Hardware Dependency: CY8CKIT-062-BLE PSoC 6 BLE Pioneer Kit
*
*******************************************************************************
* Copyright (2018), Cypress Semiconductor Corporation. All rights reserved.
*******************************************************************************
* This software, including source code, documentation and related materials
* (“Software”), is owned by Cypress Semiconductor Corporation or one of its
* subsidiaries (“Cypress”) and is protected by and subject to worldwide patent
* protection (United States and foreign), United States copyright laws and
* international treaty provisions. Therefore, you may use this Software only
* as provided in the license agreement accompanying the software package from
* which you obtained this Software (“EULA”).
*
* If no EULA applies, Cypress hereby grants you a personal, nonexclusive,
* non-transferable license to copy, modify, and compile the Software source
* code solely for use in connection with Cypress’s integrated circuit products.
* Any reproduction, modification, translation, compilation, or representation
* of this Software except as specified above is prohibited without the express
* written permission of Cypress.
*
* Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, 
* EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Cypress 
* reserves the right to make changes to the Software without notice. Cypress 
* does not assume any liability arising out of the application or use of the 
* Software or any product or circuit described in the Software. Cypress does 
* not authorize its products for use in any products where a malfunction or 
* failure of the Cypress product may reasonably be expected to result in 
* significant property damage, injury or death (“High Risk Product”). By 
* including Cypress’s product in a High Risk Product, the manufacturer of such 
* system or application assumes all risk of such use and in doing so agrees to 
* indemnify Cypress against all liability.
*******************************************************************************/
/******************************************************************************
* This file contains the task that handles BLE HTS service
*******************************************************************************/

/* Header file includes */
#include <math.h>
#include "ble_thermometer.h"
#include "temperature.h"
#include "status_indication.h"
#include "ble_thermometer_config.h"
#include "uart_debug.h"
#include "task.h"  
#include "timers.h"    

/* BLE processing interval of 15ms is used when BLE is connected */
#define BLE_FAST_INTERVAL  (pdMS_TO_TICKS(15u))
/* BLE processing interval of 100ms is used when BLE is advertising */
#define BLE_SLOW_INTERVAL  (pdMS_TO_TICKS(100u))
/* BLE idle interval is used when advertisement has timed out or when BLE 
   is disconnected */
#define BLE_IDLE_INTERVAL  (portMAX_DELAY)

/*  These static functions are not available outside this file. 
    See the respective function definitions for more details */
void static BleControllerInterruptEventHandler(void);
void static StackEventHandler(uint32_t eventType, void *eventParam);
void CallBackHts(uint32 event, void *eventParam);
void static AdvertisementEventHandler(void);
void static DisconnectEventHandler(void);
void static ProcessBleEvents(void);
void static BleTimerStart(void);
void static BleTimerUpdate(TickType_t period);

/* Variable that stores the BLE connection parameters */
cy_stc_ble_conn_handle_t static connectionHandle;  

/* Static flag used to request HTS indications */
bool static requestHtsIndication    =   false;

/* Queue handle used for commands to BLE Task */
QueueHandle_t xQueue_BleCommand; 

/* Timer handle used to control BLE Task timing */
TimerHandle_t xTimer_Ble;
                    
/*******************************************************************************
* Function Name: void Task_Ble(void *pvParameters)
********************************************************************************
* Summary:
*  Task that processes the BLE state and events, and then commands other tasks 
*  to take an action based on the current BLE state and data received over BLE  
*
* Parameters:
*  void *pvParameters : Task parameter defined during task creation (unused)                            
*
* Return:
*  void
*
*******************************************************************************/
void Task_Ble(void *pvParameters)
{
    /* Variable that stores BLE commands that need to be processed */
    ble_command_t bleCommand;
    
    /* Variable used to store the return values of BLE APIs */
    cy_en_ble_api_result_t bleApiResult;
    
    /* Variable used to store the return values of RTOS APIs */
    BaseType_t rtosApiResult;
    
    /* Remove warning for unused parameter */
    (void)pvParameters;
    
    /* Start the timer that controls the interval at which BLE events are
      processed */
    BleTimerStart();

    /* Start the BLE component and register the stack event handler */
    bleApiResult = Cy_BLE_Start(StackEventHandler);
    
    /* Check if the operation was successful */
    if(bleApiResult == CY_BLE_SUCCESS)
    {
        DebugPrintf("Success  : BLE - Stack initialization", 0u);
        
        /* Register the BLE controller (Cortex-M0+) interrupt event handler  */
        Cy_BLE_IPC_RegisterAppHostCallback(BleControllerInterruptEventHandler); 
        
        /* Register the Health Thermometer Service specific callback handler */
        Cy_BLE_HTS_RegisterAttrCallback(CallBackHts);
    }
    else
    {
        DebugPrintf("Failure! : BLE  - Stack initialization. Error Code:",
                    bleApiResult);
    }
    
    /* Repeatedly running part of the task */
    for(;;)
    {       
        /* Block until a BLE command has been received over xQueue_BleCommand */
        rtosApiResult = xQueueReceive(xQueue_BleCommand, &bleCommand,
                                      portMAX_DELAY);
        /* Command has been received from xQueue_BleCommand */
        if(rtosApiResult == pdTRUE)
        {
            /* Take an action based on the command received */
            switch (bleCommand)
            {
                /* Command to restart advertisement */                
                case BLE_RESTART_ADV:
                    /* Make sure that BLE is neither connected nor advertising
                       already */
                    if((Cy_BLE_GetConnectionState(connectionHandle) 
                       != CY_BLE_CONN_STATE_CONNECTED)&& 
                       (Cy_BLE_GetAdvertisementState() == 
                        CY_BLE_ADV_STATE_STOPPED))
                    {
                        /* Set the BLE processing interval to fast mode until 
                            the advertisement has started */
                        BleTimerUpdate(BLE_FAST_INTERVAL);
                                                
                        /* Start Advertisement and enter discoverable mode */
                		bleApiResult = Cy_BLE_GAPP_StartAdvertisement(
                                       CY_BLE_ADVERTISING_FAST,
                                       CY_BLE_PERIPHERAL_CONFIGURATION_0_INDEX); 
                        
                        /* Check if the operation was successful */
                        if(bleApiResult == CY_BLE_SUCCESS )
                        {
                            DebugPrintf("Success  : BLE - Advertisement API"
                                        , 0u);
                        }
                        else
                        {
                            DebugPrintf("Failure! : BLE - Advertisement API. "\
                                        "Error Code:" , bleApiResult);
                        }
                    }
                    break;
                        
                /*  Command to Process BLE events */
                case BLE_PROCESS_EVENTS:
                        ProcessBleEvents();
                    break;
                   
                /* Command is invalid */
                default:
                    DebugPrintf("Error!   : BLE - Invalid Task command "\
                                "received. Error Code:", bleCommand);
                    break;
            }          
        }
        /* Task has timed out and received no commands during an interval of 
            portMAXDELAY ticks */
        else
        {               
            DebugPrintf("Warning! : BLE - Task Timed out ", 0u);
        }  
    }
}

/*******************************************************************************
********************************************************************************
*  Following are the static functions used for BLE processing. These functions *
*  are not available outside this file.                                            *
********************************************************************************
*******************************************************************************/

/*******************************************************************************
* Function Name: void CallBackHts(uint32 event, void *eventParam)
********************************************************************************
*
* Summary:
*  This is an event callback function to receive events from the BLE Component,
*  which are specific to Health Thermometer Service.
*
* Parameters:  
*  event:       Event for Health Thermometer Service.
*  eventParams: Event parameter for Health Thermometer Service.
*
* Return: 
*  None
*
*******************************************************************************/
void CallBackHts(uint32 event, void *eventParam)
{
    /* Remove warning for unused parameter */
    (void)eventParam;
    
    /* Handle the HTS events */
    switch(event)
    {
        /* This event is received when indication are enabled by the central */
        case CY_BLE_EVT_HTSS_INDICATION_ENABLED:
            /* Set the requestHtsIndication flag */
            requestHtsIndication = true;
            break;

        /* This event is received when indication are enabled by the central */
        case CY_BLE_EVT_HTSS_INDICATION_DISABLED:
            /* Reset the requestHtsIndication flag */
            requestHtsIndication = false;
            break;
        
        /* Do nothing for all other events */
        default:
            break;
    }
}

/*******************************************************************************
* Function Name: void static ProcessBleEvents(void)
********************************************************************************
* Summary:
*  Function that processes BLE events and states
*
* Parameters:
*  None
*
* Return:
*  void
*
*******************************************************************************/
void static ProcessBleEvents(void)
{
    /* Variables used to store previous and current temperature commands and status
       LED data */
    temperature_command_t static prevTemperatureCommand = SEND_NONE;
    temperature_command_t     temperatureCommand;
    status_led_data_t   statusLedData;
    
    /* Variable used to store the return values of RTOS APIs */
    BaseType_t rtosApiResult;

    /* Variable used to track if BLE was in connected state */                    
    bool static bleConnected   = false;

    /* Process event callback to handle BLE events. The events and associated
       actions taken by this application are inside the 'StackEventHandler' 
       routine. Note that Cortex M4 only handles the BLE host portion of the 
       stack, while Cortex M0+ handles the BLE controller portion */
    Cy_BLE_ProcessEvents();
    
    /* Check if BLE is in connected state */
	if(Cy_BLE_GetConnectionState(connectionHandle) 
       == CY_BLE_CONN_STATE_CONNECTED)
	{     
        
        /* Temporary array to hold Health Thermometer Characteristic 
           information */
        uint8 valueArray[HTS_CHARACTERISTIC_SIZE];
        float temperature;
        temperature_data_t tempData;
                
        /* Do this if the BLE hasn't been in a connected state previously */
        if(!bleConnected)
        {
            bleConnected = true;

            /* Toggle Orange LED periodically to indicate that BLE is in a 
               connected state */
            statusLedData.orangeLed = LED_TOGGLE_EN;
            statusLedData.redLed    = LED_TURN_OFF;
            rtosApiResult = xQueueSend(xQueue_StatusLedData, &statusLedData,0u);
            
            /* Check if the operation has been successful */
            if(rtosApiResult != pdTRUE)
            {
                DebugPrintf("Failure! : BLE - Sending data to Status LED queue"
                            , 0u);   
            }
            
            /* Set the BLE processing interval to fast mode */
            BleTimerUpdate(BLE_FAST_INTERVAL);
        }
        
        /* Check if the HTS indication is required  */
        if(requestHtsIndication)
        {
            /* Request periodic temperature data */
            temperatureCommand = SEND_TEMPERATURE;
        }
        else
        {
            /* Don't request any data */
            temperatureCommand = SEND_NONE;
        }
        
        /* Check for a change in the temperature command */
        if (temperatureCommand != prevTemperatureCommand)
        {   
            /* Send the command to Temperature Task via 
               xQueue_TemperatureCommand */
            xQueueOverwrite(xQueue_TemperatureCommand, &temperatureCommand);
            
            /* Store the temperature command value for future comparisons */
            prevTemperatureCommand = temperatureCommand;
        }
        
        /* Receive temperature data from the Temperature task via 
           xQueue_TemperatureData */
        rtosApiResult = xQueueReceive(xQueue_TemperatureData, &temperature, 0);
        
        /* Data has been received from the Queue */
        if((rtosApiResult == pdTRUE)&&requestHtsIndication)
        {   
           /* Convert from IEEE-754 single precision floating point format to
               IEEE-11073 FLOAT, which is mandated by the health thermometer
               characteristic */
            tempData.temeratureValue = (int32_t)(roundf(temperature*
                                                IEEE_11073_MANTISSA_SCALER));
            tempData.temperatureArray[IEEE_11073_EXPONENT_INDEX] = 
                                                IEEE_11073_EXPONENT_VALUE;         
            
            /* Read Health Thermometer Characteristic from GATT DB */
            if(CY_BLE_SUCCESS == Cy_BLE_HTSS_GetCharacteristicValue
                                 (CY_BLE_HTS_TEMP_MEASURE,
                                  HTS_CHARACTERISTIC_SIZE, valueArray))
            { 
                /* Update temperature value in the characteristic */
                memcpy(&valueArray[HTS_TEMPERATURE_DATA_INDEX],
                       tempData.temperatureArray, HTS_TEMPERATURE_DATA_SIZE);

                /* Send indication to the central */
                Cy_BLE_HTSS_SendIndication(connectionHandle, 
                                           CY_BLE_HTS_TEMP_MEASURE,
                                           HTS_CHARACTERISTIC_SIZE, valueArray);   
            }
        }    
    }
    /* BLE is not connected */
    else
    {
        bleConnected = false;

        if(prevTemperatureCommand!= SEND_NONE)
        {  
            temperatureCommand = SEND_NONE;
            /* Request Temperature Task not to send any data if it hasn't been 
               requested previously */
            xQueueOverwrite(xQueue_TemperatureCommand, &temperatureCommand);
            prevTemperatureCommand = temperatureCommand;
        } 
	}    
}

/*******************************************************************************
* Function Name: void static StackEventHandler(uint32_t event, void *eventParam)
********************************************************************************
* Summary:
*  Call back event function to handle various events from the BLE stack. Note 
*  that Cortex M4 only handles the BLE host portion of the stack, while 
*  Cortex M0+ handles the BLE controller portion. 
*
* Parameters:
*  event        :	BLE event occurred
*  eventParam   :	Pointer to the value of event specific parameters
*
* Return:
*  void
*
*******************************************************************************/
void static StackEventHandler(uint32_t eventType, void *eventParam)
{
        
    /* Variable used to store the return values of BLE APIs */
    cy_en_ble_api_result_t bleApiResult;
    
    (void)eventParam;
    
    /* Take an action based on the current event */
    switch ((cy_en_ble_event_t)eventType)
    {
        /*~~~~~~~~~~~~~~~~~~~~~~ GENERAL  EVENTS ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
        
        /* This event is received when the BLE stack is Started */
        case CY_BLE_EVT_STACK_ON:
        
            DebugPrintf("Info     : BLE - Stack on", 0u);
            
            /* Start Advertisement and enter discoverable mode */
    		bleApiResult = Cy_BLE_GAPP_StartAdvertisement(
                            CY_BLE_ADVERTISING_FAST,
                            CY_BLE_PERIPHERAL_CONFIGURATION_0_INDEX); 

            if(bleApiResult == CY_BLE_SUCCESS )
            {
                DebugPrintf("Success  : BLE - Advertisement API", 0u);
            }
            else
            {
                DebugPrintf("Failure! : BLE - Advertisement API, Error code:"
                            , bleApiResult);
            }  
            break;
            
        /* This event is received when there is a timeout */
        case CY_BLE_EVT_TIMEOUT:
            
            DebugPrintf("Info     : BLE - Event timeout", 0u);
            break;
        
        /* This event indicates that some internal HW error has occurred */    
	    case CY_BLE_EVT_HARDWARE_ERROR:
            
            DebugPrintf("Error!   : BLE - Internal hardware error", 0u);
		    break;
            
        /*~~~~~~~~~~~~~~~~~~~~~~~~~~ GATT EVENTS ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
        
        /* This event is received when device is connected over GATT level */    
        case CY_BLE_EVT_GATT_CONNECT_IND:
            
            /* Update attribute handle on GATT Connection */
            connectionHandle = *(cy_stc_ble_conn_handle_t *) eventParam;

            DebugPrintf("Info     : BLE - GATT connection established", 0u);
            break;
        
        /* This event is received when device is disconnected */
        case CY_BLE_EVT_GATT_DISCONNECT_IND:

            DebugPrintf("Info     : BLE - GATT disconnection occurred ", 0u);
            break;

        /*~~~~~~~~~~~~~~~~~~~~~~~~~~~ GAP EVENTS ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
        
        /* This event indicates peripheral device has started/stopped
           advertising */
        case CY_BLE_EVT_GAPP_ADVERTISEMENT_START_STOP:
            
                DebugPrintf("Info     : BLE - Advertisement start/stop event"
                            ,0u);
                AdvertisementEventHandler();
            break;                
        
        /* This event is generated at the GAP Peripheral end after connection 
           is completed with peer Central device */
        case CY_BLE_EVT_GAP_DEVICE_CONNECTED:
                
                DebugPrintf("Info     : BLE - GAP device connected", 0u);   
            break;
           
        /* This event is generated when disconnected from remote device or 
           failed to establish connection */
        case CY_BLE_EVT_GAP_DEVICE_DISCONNECTED:
                
                DebugPrintf("Info     : BLE - GAP device disconnected", 0u);
                DisconnectEventHandler();
            break;            
        
        /*~~~~~~~~~~~~~~~~~~~~~~~~~~ OTHER EVENTS ~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
        
         /* See the data-type cy_en_ble_event_t to understand the event 
			occurred */
        default:
                DebugPrintf("Info     : BLE - Event code: ", eventType);
            break;
    }
} 

/*******************************************************************************
* Function Name: void static BleControllerInterruptEventHandler (void)
********************************************************************************
* Summary:
*  Call back event function to handle interrupts from BLE Controller
*  (Cortex M0+)
*
* Parameters:
*  None
*
* Return:
*  void
*
*******************************************************************************/
void static BleControllerInterruptEventHandler(void)
{
    BaseType_t xHigherPriorityTaskWoken;
    
    /* Send command to process BLE events  */
    ble_command_t bleCommand = BLE_PROCESS_EVENTS;
    xQueueSendFromISR(xQueue_BleCommand, &bleCommand,&xHigherPriorityTaskWoken);

    portYIELD_FROM_ISR(xHigherPriorityTaskWoken );
}

/*******************************************************************************
* Function Name: void static AdvertisementEventHandler(void)
********************************************************************************
* Summary:
*  This functions handles advertisement start/stop events 
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void static AdvertisementEventHandler(void)
{
    /* Variable that stores status LED data */
    status_led_data_t statusLedData;
    
    /* Variable used to store the return values of RTOS APIs */
    BaseType_t rtosApiResult;
    
    /* Check if BLE is advertising */
    if(Cy_BLE_GetAdvertisementState() == CY_BLE_ADV_STATE_ADVERTISING)
    {
        
        /* Turn on the Orange LED to indicate that BLE is advertising */
        statusLedData.orangeLed = LED_TURN_ON;
        statusLedData.redLed    = LED_TURN_OFF;
        rtosApiResult = xQueueSend(xQueue_StatusLedData, &statusLedData,0u);
        
        /* Check if the operation has been successful */
        if(rtosApiResult != pdTRUE)
        {
            DebugPrintf("Failure! : BLE - Sending data to Status LED queue", 0u);   
        }

        /* Set the BLE processing interval to slow mode */
        BleTimerUpdate(BLE_SLOW_INTERVAL);
        
    }
    /* Check if the advertisement has timed out */
    else if(Cy_BLE_GetAdvertisementState() == CY_BLE_ADV_STATE_STOPPED)
    {
        /* Turn off both status LEDs to indicate the idle mode */
        statusLedData.orangeLed = LED_TURN_OFF;
        statusLedData.redLed    = LED_TURN_OFF;
        rtosApiResult = xQueueSend(xQueue_StatusLedData, &statusLedData,0u);
        
        /* Check if the operation has been successful */
        if(rtosApiResult != pdTRUE)
        {
            DebugPrintf("Failure! : BLE - Sending data to Status LED queue", 0u);   
        }
        
        /* Set the BLE processing interval to idle mode */
        BleTimerUpdate(BLE_IDLE_INTERVAL);
    }          
}


/*******************************************************************************
* Function Name: void static DisconnectEventHandler(void)
********************************************************************************
* Summary:
*  This functions handles the disconnect event 
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void static DisconnectEventHandler(void)
{
        
    /* Variable used to store the return values of RTOS APIs */
    BaseType_t rtosApiResult;
    
    requestHtsIndication = false;
  
    /* Turn off the Orange LED and blink the Red LED once to 
       indicate disconnection*/
    status_led_data_t statusLedData = 
    {
       .orangeLed = LED_TURN_OFF,
       .redLed    = LED_BLINK_ONCE
    };
    rtosApiResult = xQueueSend(xQueue_StatusLedData, &statusLedData,0u);
    
    /* Check if the operation has been successful */
    if(rtosApiResult != pdTRUE)
    {
        DebugPrintf("Failure! : BLE - Sending data to Status LED queue", 0u);   
    }
     
    /* Set the BLE processing interval to idle mode */
    BleTimerUpdate(BLE_IDLE_INTERVAL);
}


/*******************************************************************************
* Function Name: void static BleTimerCallback(TimerHandle_t xTimer)                          
********************************************************************************
* Summary:
*  This function is called when the BLE Timer expires
*
* Parameters:
*  TimerHandle_t xTimer :  Current timer value (unused)
*
* Return:
*  void
*
*******************************************************************************/
void static BleTimerCallback(TimerHandle_t xTimer)
{

    /* Variable used to store the return values of RTOS APIs */
    BaseType_t rtosApiResult;
    
    /* Remove warning for unused parameter */
    (void)xTimer;
    
    /* Send command to process BLE events  */
    ble_command_t bleCommand = BLE_PROCESS_EVENTS;
    rtosApiResult = xQueueSend(xQueue_BleCommand, &bleCommand,0u);
    
    /* Check if the operation has been successful */
    if(rtosApiResult != pdTRUE)
    {
        DebugPrintf("Failure! : BLE - Sending command to BLE queue", 0u);   
    }
}

/*******************************************************************************
* Function Name: void static BleTimerStart(void)                     
********************************************************************************
* Summary:
*  This function starts the timer that provides timing to BLE processing
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void static BleTimerStart(void)
{
    /* Variable used to store the return values of RTOS APIs */
    BaseType_t rtosApiResult;

    /* Create an RTOS timer */
    xTimer_Ble =  xTimerCreate ("BLE Timer", BLE_FAST_INTERVAL, pdTRUE, NULL,
                                BleTimerCallback);
    
    /* Make sure that timer handle is valid */
    if (xTimer_Ble != NULL)
    {
        /* Start the timer */
        rtosApiResult = xTimerStart(xTimer_Ble, 0u);
        
        /* Check if the operation has been successful */
        if(rtosApiResult != pdPASS)
        {
            DebugPrintf("Failure! : BLE  - Timer initialization", 0u);    
        }
    }
    else
    {
        DebugPrintf("Failure! : BLE  - Timer creation", 0u); 
    }
}

/*******************************************************************************
* Function Name: void static BleTimerUpdate(TickType_t period)                   
********************************************************************************
* Summary:
*  This function updates the timer period per the parameter
*
* Parameters:
*  TickType_t period :  Period of the timer in ticks
*
* Return:
*  void
*
*******************************************************************************/
void static BleTimerUpdate(TickType_t period)
{
    /* Variable used to store the return values of RTOS APIs */
    BaseType_t rtosApiResult;
    
    /* Change the timer period */
    rtosApiResult = xTimerChangePeriod(xTimer_Ble, period, 0u);
    
    /* Check if the operation has been successful */
    if(rtosApiResult != pdPASS)
    {
        DebugPrintf("Failure! : BLE - Timer update ", 0u);   
    } 
}

/* [] END OF FILE */
